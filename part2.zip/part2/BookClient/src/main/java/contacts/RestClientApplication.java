package contacts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class RestClientApplication implements CommandLineRunner {

    @Autowired
    private RestTemplate restTemplate;

    public static void main(String[] args) {
        SpringApplication.run(RestClientApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        String serverUrl = "http://localhost:8080/books";

        restTemplate.postForLocation(serverUrl, new Book("978-3-16-148410-0", "Pranjal","My book",230));


        Book book = restTemplate.getForObject(serverUrl + "/{isbn}", Book.class, "978-3-16-148410-0");
        System.out.println("Retrieved book: " + book.getTitle() + " by " + book.getAuthor());

        Books books = restTemplate.getForObject(serverUrl, Books.class);
        System.out.println("All books: " + books);

        book.setTitle("Spring Boot in Action (Updated)");
        restTemplate.put(serverUrl + "/{isbn}", book, book.getIsbn());

        books = restTemplate.getForObject(serverUrl, Books.class);
        System.out.println("Updated books: " + books);

        restTemplate.delete(serverUrl + "/{isbn}", "978-3-16-148410-0");

        books = restTemplate.getForObject(serverUrl, Books.class);
        System.out.println("Books after deletion: " + books);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}