package books.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import books.domain.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class JmsSender {

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    public void sendMessage(Book book) {
        try {
            String bookAsString = objectMapper.writeValueAsString(book);
            System.out.println("Sending a JMS message: " + bookAsString);
            jmsTemplate.convertAndSend("testQueue", bookAsString);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
